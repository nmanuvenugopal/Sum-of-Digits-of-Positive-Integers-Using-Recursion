number = int(input("Enter the number: "))

def sum_of_digit(num):
    assert num>=0 and int(num)==num, "Number has to be positive integer"
    if num == 0:
        return 0
    else:
        return (num % 10) + sum_of_digit(int(num/10))

print(f"Sum of Digits of {number} is : {sum_of_digit(number)}")